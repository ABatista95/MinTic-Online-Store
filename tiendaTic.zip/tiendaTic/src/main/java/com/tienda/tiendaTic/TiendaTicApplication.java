package com.tienda.tiendaTic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaTicApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaTicApplication.class, args);
	}

}
